import os #Create or Remove the dictonary and manage dictonary
import shutil #to manage copy move any files


folderpath = r'Your Source Folder' #with Read operation
os.chdir(folderpath)
os.getcwd() #get that directory

os.listdir() #to get the list of all files


list_extension = [] #For get all possible extentions
for fname in os.listdir():
    extension = fname.split(".")[-1]  #thisis.xml -> xml
    list_extension.append(extension)
    # print(list_extension)

list_extension = set(list_extension)
print(list_extension)
print(len(list_extension))


path = os.environ["UserProfile"] + "\\" + "Desktop" + "\\" + 'Folder Name That You Want To Create'
print(path)
os.mkdir(path)
try:
    shutil.rmtree(path)
    os.mkdir(path)
except:
    os.mkdir(path)


for ex in list_extension:
    print(ex, end=",")
    os.mkdir(path + "\\" + ex)
    for fname in os.listdir():
        if ex in fname:
            shutil.copy(fname, path + "\\" + ex)